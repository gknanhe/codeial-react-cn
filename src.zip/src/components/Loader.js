const Loader = () => {
    return <div className="app-spinner"></div>
}

export default Loader;