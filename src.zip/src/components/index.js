
import App from './App';

export {
  App
}